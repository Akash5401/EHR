module.exports = {
    User: require("./User"),
    Patient: require("./Patient")
};