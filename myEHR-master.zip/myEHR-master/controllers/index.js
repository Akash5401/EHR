module.exports = {
    UsrCtrl: require("./userController"),
    PntCtrl: require("./patientController")
}