module.exports = {
    passport: require('./localStrategy')
}